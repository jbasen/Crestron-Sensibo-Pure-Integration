﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Https;
using Newtonsoft.Json;

namespace Sensibo_Pure_Integration
{
	#region Delegates
	public delegate void DelegateFn(ushort Purifier_On, ushort Fan_Level, ushort Light_On, ushort pm25, ushort PureBoost_On);
	public delegate void DelegateFn1(ushort Purifier_On, ushort Fan_Level, ushort Light_On);
	public delegate void DelegateFn2(ushort PureBoost_On);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Sensibo_Pure
	{
		public DelegateFn callback_fn { get; set; }
		public DelegateFn1 callback_fn1 { get; set; }
		public DelegateFn2 callback_fn2 { get; set; }

		#region Declarations
		private string API_Key;
		private string Device_ID;
		private static Debug_Options Debug;
		private bool on;
		private string mode;
		private string fanLevel;
		private string light;
		#endregion

		//****************************************************************************************
		// 
		//  Sensibo_Pure	-	Default Constructor
		// 
		//****************************************************************************************
		public Sensibo_Pure()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public void Initialize(string Device_ID, string API_Key, short Debug)
		{
			#region Save Parameters
			this.API_Key = API_Key;
			this.Device_ID = Device_ID;
			#endregion

			Set_Debug_Message_Output(Debug);

			Refresh();

			Debug_Message("Initialize", "SUCCESS");
		}

		//****************************************************************************************
		// 
		//  Refresh	-	Get Device status
		// 
		//****************************************************************************************
		public void Refresh()
		{
			#region Variables for passing back data to S+
			ushort Purifier_On;
			ushort light_status;
			ushort fan_status;
			ushort PureBoost_On;
			#endregion

			Debug_Message("Refresh", "Start");

			#region Create url
			string url = "";

			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Pure - Refresh - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Pure - Refresh - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return;
			}

			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "?fields=*&apiKey=" + API_Key;
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Get;
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Pure - Refresh - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Refresh", "ContentString = " + ContentString);

					#region Parse asState info from returned json
					string s = ContentString;
					int i = s.IndexOf("\"acState\"", 0);
					i = s.IndexOf("{", i);
					int j = s.IndexOf(", \"location\":", 0);
					s = s.Substring(i, j - i);
					Debug_Message("Refresh", "s = " + s);
					acState state = acState.Parse(s);
					if (state == null)
					{
						return;
					}
					#endregion

					#region Parse measurements from returned json
					s = ContentString;
					i = s.IndexOf("\"measurements\"", 0);
					i = s.IndexOf("{", i);
					j = s.IndexOf(", \"accessPoint\":", 0);
					s = s.Substring(i, j - i);
					Debug_Message("Refresh", "s = " + s);
					measurements Measurement = measurements.Parse(s);
					if (state == null)
					{
						return;
					}
					#endregion	

					#region Parse pureBoostConfig from returned json
					s = ContentString;
					i = s.IndexOf("\"pureBoostConfig\"", 0);
					i = s.IndexOf("{", i);
					j = s.IndexOf(", \"warrantyEligible\":", 0);
					s = s.Substring(i, j - i);
					Debug_Message("Refresh", "s = " + s);
					pureBoostConfig Pure_Boost = pureBoostConfig.Parse(s);
					if (Pure_Boost == null)
					{
						return;
					}
					#endregion

					#region Send Back to S+
					Purifier_On = (state.on == true) ? (ushort) 1 : (ushort) 0;
					switch (state.light)
					{
						case "on":
							light_status = 1;
							break;

						case "off":
							light_status = 0;
							break;

						case "dim":
							light_status = 2;
							break;

						default:
							light_status = 0;
							break;
					}
					if (state.fanLevel == "low")
					{
						fan_status = 0;
					}
					else
					{
						fan_status = 1;
					}
					PureBoost_On = (Pure_Boost.enabled == true) ? (ushort)1 : (ushort)0;
					callback_fn(Purifier_On, fan_status, light_status, Measurement.pm25, PureBoost_On);
					#endregion

					#region Save to Globals
					on = state.on;
					mode = state.mode;
					fanLevel = state.fanLevel;
					this.light = state.light;
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Pure - Refresh - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Power	-	turn power on/off
		// 
		//****************************************************************************************
		public void Set_Power(string power_on)
		{
			#region Create url
			string url = "";
			string payload = "";

			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Pure - Set_Power - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Pure - Set_Power - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}

			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Power", "url = " + url);
			#endregion

			#region Create Payload
			payload = "{\"acState\": {\"on\": " + power_on + ",\"mode\": \"" + mode + "\",\"fanLevel\": \"" + fanLevel + "\",\"light\": \"" + light + "\"}}";
			Debug_Message("Set_Power", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Pure - Set_Power - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Set_Power", "ContentString = " + ContentString);

					#region Parse asState info from returned json
					string s = ContentString;
					int i = s.IndexOf("\"acState\"", 0);
					i = s.IndexOf("{", i);
					int j = s.IndexOf(", \"changedProperties\":", 0);
					s = s.Substring(i, j - i);
					Debug_Message("Set_Power", "s = " + s);
					acState state = acState.Parse(s);
					if (state == null)
					{
						return;
					}
					#endregion

					#region Send Back to S+
					ushort Purifier_On = (state.on == true) ? (ushort)1 : (ushort)0;
					ushort light_status;
					switch (state.light)
					{
						case "on":
							light_status = 1;
							break;

						case "off":
							light_status = 0;
							break;

						case "dim":
							light_status = 2;
							break;

						default:
							light_status = 0;
							break;
					}
					ushort fan_status;
					if (state.fanLevel == "low")
					{
						fan_status = 0;
					}
					else
					{
						fan_status = 1;
					}
					callback_fn1(Purifier_On, fan_status, light_status);
					#endregion

					#region Save to Globals
					on = state.on;
					mode = state.mode;
					fanLevel = state.fanLevel;
					light = state.light;
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Pure - Set_Power - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Light	-	turn light on/off/dim
		// 
		//****************************************************************************************
		public void Set_Light(string light_state)
		{
			#region Create url
			string url = "";
			string payload = "";

			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Pure - Set_Light - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Pure - Set_Light - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}

			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Light", "url = " + url);
			#endregion

			#region Create Payload
			string power_on = (on == true) ? "true" : "false";
			payload = "{\"acState\": {\"on\": " + power_on + ",\"mode\": \"" + mode + "\",\"fanLevel\": \"" + fanLevel + "\",\"light\": \"" + light_state + "\"}}";
			Debug_Message("Set_Light", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Pure - Set_Light - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Set_Light", "ContentString = " + ContentString);

					#region Parse asState info from returned json
					string s = ContentString;
					int i = s.IndexOf("\"acState\"", 0);
					i = s.IndexOf("{", i);
					int j = s.IndexOf(", \"changedProperties\":", 0);
					s = s.Substring(i, j - i);
					Debug_Message("Set_Light", "s = " + s);
					acState state = acState.Parse(s);
					if (state == null)
					{
						return;
					}
					#endregion

					#region Send Back to S+
					ushort Purifier_On = (state.on == true) ? (ushort)1 : (ushort)0;
					ushort light_status;
					switch (state.light)
					{
						case "on":
							light_status = 1;
							break;

						case "off":
							light_status = 0;
							break;

						case "dim":
							light_status = 2;
							break;

						default:
							light_status = 0;
							break;
					}
					ushort fan_status;
					if (state.fanLevel == "low")
					{
						fan_status = 0;
					}
					else
					{
						fan_status = 1;
					}
					callback_fn1(Purifier_On, fan_status, light_status);
					#endregion

					#region Save to Globals
					on = state.on;
					mode = state.mode;
					fanLevel = state.fanLevel;
					light = state.light;
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Pure - Set_Light - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Fan	-	set fan to high/low
		// 
		//****************************************************************************************
		public void Set_Fan(string fan_state)
		{
			#region Create url
			string url = "";
			string payload = "";

			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Pure - Set_Fan - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Pure - Set_Fan - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}

			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/acStates?apiKey=" + API_Key;
			Debug_Message("Set_Light", "url = " + url);
			#endregion

			#region Create Payload
			string power_on = (on == true) ? "true" : "false";
			payload = "{\"acState\": {\"on\": " + power_on + ",\"mode\": \"" + mode + "\",\"fanLevel\": \"" + fan_state + "\",\"light\": \"" + light + "\"}}";
			Debug_Message("Set_Fan", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Post;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Pure - Set_Fan - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Set_Fan", "ContentString = " + ContentString);

					#region Parse asState info from returned json
					string s = ContentString;
					int i = s.IndexOf("\"acState\"", 0);
					i = s.IndexOf("{", i);
					int j = s.IndexOf(", \"changedProperties\":", 0);
					s = s.Substring(i, j - i);
					Debug_Message("Set_Fan", "s = " + s);
					acState state = acState.Parse(s);
					if (state == null)
					{
						return;
					}
					#endregion

					#region Send Back to S+
					ushort Purifier_On = (state.on == true) ? (ushort)1 : (ushort)0;
					ushort light_status;
					switch (state.light)
					{
						case "on":
							light_status = 1;
							break;

						case "off":
							light_status = 0;
							break;

						case "dim":
							light_status = 2;
							break;

						default:
							light_status = 0;
							break;
					}
					ushort fan_status;
					if (state.fanLevel == "low")
					{
						fan_status = 0;
					}
					else
					{
						fan_status = 1;
					}
					callback_fn1(Purifier_On, fan_status, light_status);
					#endregion

					#region Save to Globals
					on = state.on;
					mode = state.mode;
					fanLevel = state.fanLevel;
					light = state.light;
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Pure - Set_Fan - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_pureBoost	-	set pureBoost on/off
		// 
		//****************************************************************************************
		public void Set_pureBoost(string state)
		{
			Debug_Message("Set_pureBoost", "Start");

			#region Create url
			string url = "";
			string payload = "";

			if (string.IsNullOrEmpty(API_Key))
			{
				string err = "Sensibo_Pure - Set_pureBoost - API_Key Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			else if (string.IsNullOrEmpty(Device_ID))
			{
				string err = "Sensibo_Pure - Set_pureBoost - Device_ID Not Set";
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}

			url = "https://home.sensibo.com/api/v2/pods/" + Device_ID + "/pureboost" + "?apiKey=" + API_Key;
			Debug_Message("Set_pureBoost", "url = " + url);
			#endregion

			#region Create Payload
			payload = "{\"enabled\": " + state + "}";
			Debug_Message("Set_pureBoost", "payload = " + payload);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpsClient client = new HttpsClient();
				HttpsClientRequest request = new HttpsClientRequest();
				HttpsClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Https.RequestType.Put;
				request.ContentString = payload;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(payload.Length));
				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Sensibo_Pure - Set_pureBoost - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Set_pureBoost", "ContentString = " + ContentString);
					string s = ContentString;
					int i = s.IndexOf("\"result\"", 0);
					i = s.IndexOf("{", i);
					int j = s.IndexOf("}", i) + 1;
					s = s.Substring(i, j - i);
					Debug_Message("Set_pureBoost", "s = " + s);
					pureBoostConfig Pure_Boost = pureBoostConfig.Parse(s);
					if (Pure_Boost == null)
					{
						return;
					}
					callback_fn2((Pure_Boost.enabled == true) ? (ushort)1 : (ushort)0);
				}
			}
			catch (Exception e)
			{
				string err = "Sensibo_Pure - Set_pureBoost - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Sensibo_Pure.Debug = Debug_Options.None;
					break;

				case 1:
					Sensibo_Pure.Debug = Debug_Options.Console;
					break;

				case 2:
					Sensibo_Pure.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Sensibo_Pure.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 200;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Sensibo_Pure - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Sensibo_Pure - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}

	//****************************************************************************************
	// 
	//  acState	-	Class for parsing acState info
	// 
	//****************************************************************************************
	public class acState
	{
		#region Declarations
		public bool on { get; set; }
		public string mode { get; set; }
		public string fanLevel { get; set; }
		public string light { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-	Parse AC State from Json
		// 
		//****************************************************************************************
		public static acState Parse(string JSON)
		{
			try
			{
				acState Data = JsonConvert.DeserializeObject<acState>(JSON);
				return Data;
			}
			catch (Exception e)
			{
				string err = "Sensibo Pure - acState - Parse - Error Parsing JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}

	//****************************************************************************************
	// 
	//  measurements	-	Class for parsing measurements info
	// 
	//****************************************************************************************
	public class measurements
	{
		#region Declarations
		public ushort pm25 { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-	Parse measurements from Json
		// 
		//****************************************************************************************
		public static measurements Parse(string JSON)
		{
			try
			{
				measurements Data = JsonConvert.DeserializeObject<measurements>(JSON);
				return Data;
			}
			catch (Exception e)
			{
				string err = "Sensibo Pure - measurements - Parse - Error Parsing JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}

	//****************************************************************************************
	// 
	//  pureBoostConfig	-	Class for parsing pureBoostConfig info
	// 
	//****************************************************************************************
	public class pureBoostConfig
	{
		#region Declarations
		public bool enabled { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-	Parse pureBoostConfig from Json
		// 
		//****************************************************************************************
		public static pureBoostConfig Parse(string JSON)
		{
			try
			{
				pureBoostConfig Data = JsonConvert.DeserializeObject<pureBoostConfig>(JSON);
				return Data;
			}
			catch (Exception e)
			{
				string err = "Sensibo Pure - pureBoostConfig - Parse - Error Parsing JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}
}
