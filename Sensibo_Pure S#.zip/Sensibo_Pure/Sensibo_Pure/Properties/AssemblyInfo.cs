﻿using System.Reflection;

[assembly: AssemblyTitle("Sensibo_Pure")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Sensibo_Pure")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2021")]
[assembly: AssemblyVersion("1.0.0.*")]

